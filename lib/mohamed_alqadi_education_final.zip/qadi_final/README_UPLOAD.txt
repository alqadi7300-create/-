النسخة الأخيرة - برنامج محمد القاضي التعليمي العلمي

الملفات المهمة:
1) lib/main.dart
2) pubspec.yaml
3) assets/teacher_mohamed_alqadi.png

في GitHub:
- ارفع main.dart داخل lib واستبدل أي main.dart موجود هناك.
- ارفع pubspec.yaml في جذر المستودع واستبدل القديم.
- أنشئ مجلد assets في جذر المستودع، ثم ارفع داخله teacher_mohamed_alqadi.png.
- لا تعتمد على main.dart الموجود في جذر المستودع؛ Flutter يستخدم lib/main.dart.

لأيقونة التطبيق، يجب أن يحتوي GitHub Actions على:
dart run flutter_launcher_icons
بعد flutter pub get وقبل flutter build apk --release.
